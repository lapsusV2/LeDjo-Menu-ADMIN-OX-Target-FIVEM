fx_version 'adamant'
game 'gta5'
developer 'LeDjo_Developpement'
discord 'https://discord.gg/nKVQW5Q5js'
lua54 'yes'
ui_page 'html/index.html'


shared_scripts {
	'@ox_lib/init.lua',
	'@es_extended/imports.lua',
	'config.lua'
}

client_scripts {
	'@es_extended/locale.lua',
	'client/client.lua',
	'client/cl_edit.lua',
	'server/server.lua',
} 

server_scripts {
	'@es_extended/locale.lua',
	'@mysql-async/lib/MySQL.lua',
	'@oxmysql/lib/MySQL.lua',
	'server/server.lua',
	'client/client.lua',
	'server/sv_edit.lua'
}

files {
    'locales/*.json',
	'html/index.html',
	'html/jquery.js',
	'html/init.js',
}

escrow_ignore {
	'locales/*.json',
	'config.lua',
	'client/cl_edit.lua',
	'server/sv_edit.lua'
}
